//#include "WHPublic.h"

//GameLayer *g_gameLayer;
//PlayerLayer *g_playerLayer;
//bool can_ctl = true;